<template>
  <div style='width: 100%'>
    <el-popover
      placement='right'
      trigger='hover'
      :disabled='tooltipList.length === 0'
      :width='200'
    >
      <div>
        <el-tag
          v-for='item in tooltipList'
          :key='item.value'
          class='selected-tag'
          :closable='disabled === false'
          @close='onClose(item)'>
          {{ item.label }}
        </el-tag>
      </div>
      <template #reference>
        <el-select-v2
          v-if='ready'
          class='biz-select multiple'
          :class='{filterable:filterable, "multiple-line": multipleLine}'
          style='width: 100%'
          :model-value='selectData.selected'
          :options='selectData.options'
          :placeholder='placeholder'
          multiple
          :disabled='disabled'
          :collapse-tags='!multipleLine'
          clearable
          :remote='remote'
          :remote-method='remoteMethod'
          :filterable='filterable'
          :loading='loading'
          @update:model-value='onUpdateModelValue'
          @change='onChange'
          @blur='onBlur'
          @focus='onFocus'
          @clear='onClear'
          @visible-change='onVisibleChange'
          @remove-tag='onRemoveTag'
        />
        <el-button v-else loading />
      </template>
    </el-popover>
  </div>
</template>

<script setup>
import { onMounted, ref, watch, reactive, computed } from 'vue'; 
import { cloneDeep, differenceWith, isEqual, debounce } from 'lodash';

const props = defineProps({
  modelValue: {
    type: Array,
    default: undefined
  },
  placeholder: {
    type: String,
    default: '请选择'
  },
  fetchData: {
    type: Function,
    default: () => []
  },
  filterable: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  },
  multipleLine: {
    type: Boolean,
    default: false
  },
  remote: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits([
  'update:modelValue',
  'update:label',
  'change',
  'blur',
  'focus',
  'clear',
  'visible-change',
  'remove-tag'
]);

const loading = ref(false);
const ready = ref(false);
const selectData = reactive({
  selected: [],
  options: [] 
});
const tooltipList = computed(() => selectData.selected.map(selectedValue => selectData.options.find(item => item.value === selectedValue)).filter(item => item !== undefined));

watch(() => props.modelValue, (newValue) => {
  if (newValue.length !== selectData.selected.length || differenceWith(newValue, selectData.selected, isEqual).length > 0) {
    selectData.selected = cloneDeep(newValue);
  }
  return;
}, { deep: true });

const selectedLabel = computed(() => selectData.selected.map(value => {
  const result = selectData.options.find((option => option.value === value));
  if (result === undefined) {
    return undefined;
  } else {
    return result.label;
  }
}));

watch(selectedLabel, (value) => {
  emit('update:label', cloneDeep(value));
}, { deep: true });

onMounted(async () => {
  selectData.selected = cloneDeep(props.modelValue);
  let res = await props.fetchData();
  selectData.options = res;
  ready.value = true;
});

const onUpdateModelValue = (newValue) => {
  console.log('multiple-select', 'update:modelValue', newValue);
  emit('update:modelValue', cloneDeep(newValue));
};

const onClose = (item) => {
  selectData.selected = selectData.selected.filter(id => id !== item.value);
  emit('update:modelValue', cloneDeep(selectData.selected));
};

const onChange = (val) => {
  emit('change', val);
};

const onBlur = (event) => {
  emit('blur', event);
};

const onFocus = (event) => {
  emit('focus', event);
};

const onClear = () => {
  emit('clear');
};

const onVisibleChange = (val) => {
  emit('visible-change', val);
};

const onRemoveTag = (val) => {
  emit('remove-tag', val);
};

const fetchDataDebounce = debounce(async (query) => {
  const res = await props.fetchData(query);
  selectData.options = res;
  loading.value = false;
}, 300);

const remoteMethod = (query) => {
  if (!props.remote) return;
  loading.value = true;
  fetchDataDebounce(query);
};

</script>

<style lang="scss" scoped>
.selected-tag{
  margin: 0 4px 4px 0;
  max-width:170px;
  box-sizing: border-box;
  
  ::v-deep(.el-tag__content){
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 134px;
  }
}
.biz-select.multiple {
  &:not(.multiple-line){

  &.filterable {
    ::v-deep(.el-select-v2__selection){
      .el-select-v2__selected-item{
      
        max-width: 75%;

        &:nth-child(2){
          max-width: none !important;
          width: 25% !important;
        }
      }
    }
  }

  &:not(.filterable){
    ::v-deep(.el-select-v2__selection){
      .el-select-v2__selected-item{
        &:nth-child(2){
          width: 0!important;
          margin: 0;
        }
      }
    }
  }

  ::v-deep(.el-select-v2__selection){
    flex-wrap: nowrap;
    flex: 1;
    overflow: hidden;
    .el-select-v2__selected-item{
      overflow: hidden;
      flex: 1;
      display: flex;

      &.el-select-v2__input-wrapper{
        flex: none;
        display: block;

      }

      .el-tag{
        flex: none;
        &:first-child{
          flex: 1;
          overflow: hidden;
          .el-tag__content{
            width: calc(100% - 21px);

            .el-select-v2__tags-text{
              min-width: none !important;
              width: 100%;
            }
          }
        }
      }
    }
  }
}
}
</style>