<template>
  <el-select-v2
    v-if='ready'
    style='width: 100%'
    :model-value='selectData.selected'
    :options='selectData.options'
    :placeholder='placeholder'
    :disabled='disabled'
    clearable
    :remote='remote'
    :remote-method='remoteMethod'
    :filterable='filterable'
    :loading='loading'
    @update:model-value='onUpdateModelValue'
    @change='onChange'
    @blur='onBlur'
    @focus='onFocus'
    @clear='onClear'
    @visible-change='onVisibleChange'
    @remove-tag='onRemoveTag'
  />
  <el-button v-else loading />
</template>

<script setup>
import { onMounted, ref, watch, reactive, computed } from 'vue'; 
import { debounce } from 'lodash';

const props = defineProps({
  modelValue: {
    type: [String, Number],
    default: undefined
  },
  placeholder: {
    type: String,
    default: '请选择'
  },
  fetchData: {
    type: Function,
    default: () => []
  },
  filterable: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  },
  selectFirst: {
    type: Boolean,
    default: false
  },
  remote: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits([
  'update:modelValue',
  'update:label',
  'change',
  'blur',
  'focus',
  'clear',
  'visible-change',
  'remove-tag'
]);

const loading = ref(false);
const ready = ref(false);
const selectData = reactive({
  selected: null,
  options: [] 
});

watch(() => props.modelValue, (newValue) => {
  selectData.selected = newValue;

  
});

const selectedLabel = computed(() => {
  const item = selectData.options.find(option => option.value === selectData.selected);
  if (item === undefined) {
    return undefined;
  } else {
    return item.label;
  }
});

watch(selectedLabel, (value) => {
  emit('update:label', value);
});

onMounted(async () => {
  selectData.selected = props.modelValue;
  let res = await props.fetchData();
  selectData.options = res;
  if (props.selectFirst && (props.modelValue === undefined || props.modelValue === null || props.modelValue === '') && selectData.options.length > 0) {
    selectData.selected = selectData.options[0].value;
    emit('update:modelValue', selectData.options[0].value);
  }
  ready.value = true;
});

const onUpdateModelValue = (newValue) => {
  console.log('single-select', 'update:modelValue', newValue);
  emit('update:modelValue', newValue);
};

const onChange = (val) => {
  emit('change', val);
};

const onBlur = (event) => {
  emit('blur', event);
};

const onFocus = (event) => {
  emit('focus', event);
};

const onClear = () => {
  emit('clear');
};

const onVisibleChange = (val) => {
  emit('visible-change', val);
};

const onRemoveTag = (val) => {
  emit('remove-tag', val);
};

const fetchDataDebounce = debounce(async (query) => {
  const res = await props.fetchData(query);
  selectData.options = res;
  loading.value = false;
}, 300);

const remoteMethod = async (query) => {
  if (!props.remote) return;
  loading.value = true;
  fetchDataDebounce(query);
};
</script>

<style lang="scss" scoped>

</style>