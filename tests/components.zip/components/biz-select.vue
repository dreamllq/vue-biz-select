<template>
  <biz-single-select
    v-if='multiple === false'
    :model-value='modelValue'
    :placeholder='placeholder'
    :filterable='filterable'
    :fetch-data='fetchData'
    :disabled='disabled'
    :select-first='selectFirst'
    :remote='remote'
    @update:model-value='onUpdateModelValue'
    @update:label='onUpdateLabel' 
    @change='onChange' 
    @blur='onBlur'
    @focus='onFocus'
    @clear='onClear'
    @visible-change='onVisibleChange'
    @remove-tag='onRemoveTag'
  />
  <biz-multiple-select
    v-else
    :model-value='modelValue'
    :placeholder='placeholder'
    :filterable='filterable'
    :fetch-data='fetchData'
    :disabled='disabled'
    :multiple-line='multipleLine'
    :remote='remote'
    @update:model-value='onUpdateModelValue'
    @update:label='onUpdateLabel' 
    @change='onChange' 
    @blur='onBlur'
    @focus='onFocus'
    @clear='onClear'
    @visible-change='onVisibleChange'
    @remove-tag='onRemoveTag'
  />
</template>

<script setup>
import BizMultipleSelect from './biz-multiple-select.vue';
import BizSingleSelect from './biz-single-select.vue';

const props = defineProps({
  fetchData: {
    type: Function,
    default: () => []
  },
  modelValue: {
    type: [
      Array,
      String,
      Number
    ],
    default: undefined
  },
  placeholder: {
    type: String,
    default: '请选择'
  },
  multiple: {
    type: Boolean,
    default: false
  },
  filterable: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  },
  multipleLine: {
    type: Boolean,
    default: false
  },
  selectFirst: {
    type: Boolean,
    default: false
  },
  remote: {
    type: Boolean,
    default: false
  }
});
const emit = defineEmits([
  'update:modelValue',
  'update:label',
  'change',
  'blur',
  'focus',
  'clear',
  'visible-change',
  'remove-tag'
]);

const onUpdateModelValue = (newValue) => {
  emit('update:modelValue', newValue);
};

const onUpdateLabel = (newValue) => {
  emit('update:label', newValue);
};

const onChange = (val) => {
  emit('change', val);
};

const onBlur = (event) => {
  emit('blur', event);
};

const onFocus = (event) => {
  emit('blur', event);
};

const onClear = () => {
  emit('clear');
};

const onVisibleChange = (val) => {
  emit('visible-change', val);
};

const onRemoveTag = (val) => {
  emit('remove-tag', val);
};

</script>

<style lang="scss" scoped>

</style>